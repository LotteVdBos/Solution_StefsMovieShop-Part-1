﻿
DROP TABLE __EFMigrationsHistory
DROP TABLE AspNetRoleClaims
DROP TABLE AspNetRoles
DROP TABLE AspNetUserClaims
DROP TABLE AspNetUserLogins
DROP TABLE AspNetUserRoles
DROP TABLE AspNetUsers
DROP TABLE AspNetUserTokens
DROP TABLE DeviceCodes
DROP TABLE PersistedGrants

DROP TABLE Actors
DROP TABLE Categories
