﻿using StefsMovieShop.Shared.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace StefsMovieShop.Client.Interfaces
{
    public interface IMoviesRepo
    {
        Task<MovieDto> GetMovie(int id);
        Task<IEnumerable<MovieDto>> GetMovies();
        Task<MovieDto> DeleteMovie(int id);
    }
}
