﻿using StefsMovieShop.Client.Interfaces;
using StefsMovieShop.Shared.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace StefsMovieShop.Client.Repos
{
    public class MoviesRepo : IMoviesRepo
    {
        //fields
        private readonly HttpClient http;
        private readonly HttpClient https;
        private string url = "/api/movies";

        //ctor   
        public MoviesRepo(IHttpClientFactory httpClientFactory)
        {
            this.http = httpClientFactory.CreateClient("NotSecured");
            this.https = httpClientFactory.CreateClient("Secured");
        }

        public async Task<IEnumerable<MovieDto>> GetMovies()
        {
            return await http.GetFromJsonAsync<IEnumerable<MovieDto>>($"{url}");
        }

        public async Task<MovieDto> GetMovie(int id)
        {
            return await https.GetFromJsonAsync<MovieDto>($"{url}/{id}");
        }

        public Task<MovieDto> DeleteMovie(int id)
        {
            throw new NotImplementedException();
        }

        //public async Task<MovieDto> DeleteMovie(int id)
        //{
        //    return await http.DeleteAsync<MovieDto>($"{url}/{id}");
        //}
    }
}
